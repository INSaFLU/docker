java -jar /opt/mauve_snapshot_2015-02-13/Mauve.jar
